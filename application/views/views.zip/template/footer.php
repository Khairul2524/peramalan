<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Versi</b> 1.0.0
    </div>
    <strong>Copyright &copy; <?= date('Y') ?>. Exponential Smoothing | Hakakode.site</strong>
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<!-- Bootstrap 4 -->
<script src="<?= base_url('assets/backand/') ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url('assets/backand/') ?>dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?= base_url('assets/backand/') ?>dist/js/demo.js"></script>
<!-- Datepiker -->
<!-- <script src="<?= base_url('assets/backand/') ?>dist/js/bootstrap-datepicker.js"></script> -->
<!-- sweetalert -->
<script src="<?= base_url('assets/backand/') ?>dist/js/sweetalert2.all.min.js"></script>
<!-- My Script -->
<script src="<?= base_url('assets/backand/') ?>dist/js/script.js"></script>



</body>

</html>