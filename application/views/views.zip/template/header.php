<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SIPE</title>

    <link rel="shortcut icon" href="<?= base_url('assets/backand/dist/img/logostmik.png') ?>" type="image/x-icon">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?= base_url('assets/backand/') ?>plugins/fontawesome-free/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url('assets/backand/') ?>dist/css/adminlte.min.css">
    <!-- fon viga -->
    <link rel="stylesheet" href="<?= base_url('assets/backand/') ?>dist/css/viga.css">
    <!-- mycss -->
    <link rel="stylesheet" href="<?= base_url('assets/backand/') ?>dist/css/mycss.css">
    <!-- jQuery -->
    <script src="<?= base_url('assets/backand/') ?>dist/js/jquery-3.5.1.js"></script>

</head>

<body class="hold-transition sidebar-mini layout-navbar-fixed layout-fixed">
    <!-- Site wrapper -->
    <div class="wrapper">